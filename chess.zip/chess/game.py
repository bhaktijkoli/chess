import pygame

pygame.init()

display_width = 400
display_height = 400

block_height = 50
block_width = 50

white = (255, 255, 255)
black = (0, 0, 0)
teal = (0, 128, 128)

game_display = pygame.display.set_mode((display_width, display_height))
pygame.display.update()
clock = pygame.time.Clock()


class piece:
    x = 0
    y = 0
    rank = ""
    life = True
    family = ""
    pic = ""

    def __init__(self, x_position, y_position, p_rank, p_family):
        self.x = x_position
        self.y = y_position
        self.rank = p_rank
        self.family = p_family


pie = []
pie.append(piece(25, 25, "p", "black"))
pie.append(piece(75, 25, "p", "black"))
pie.append(piece(125, 25, "p", "black"))

print(pie[1].x)
def initialize_piece():
    i = 0
    while i < 3:
        if pie[i].rank == "p":
            pygame.draw.rect(game_display, black, (pie[i].x, pie[i].y, 12, 12))
        i += 1


def move():
    pie[1].x += 0


def board_draw():
    x = 0
    y = 0
    while y <= display_height:
        if y % (2 * block_height) is 0:
            x = 0
        else:
            x = block_width

        while x <= display_width:
            pygame.draw.rect(game_display, white, (x, y, block_width, block_height))
            x += (2 * block_width)
        y += block_height
    x = 0
    y = 0
    while y <= display_height:
        if y % (2 * block_height) is 0:
            x = block_width
        else:
            x = 0

        while x <= display_width:
            pygame.draw.rect(game_display, teal, (x, y, block_width, block_height))
            x += (2 * block_width)
        y += block_height
    pygame.display.update()


def game():
    while True:
        board_draw()
        initialize_piece()
        move()
        for event in pygame.event.get():
            if event.type== pygame.MOUSEBUTTONUP:
                pos = pygame.mouse.get_pos()
                print(pos)
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        pygame.display.update()
        clock.tick(1)


game()
