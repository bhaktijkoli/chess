#########################################################################################################
############  Vidhyanshu __ Jain ########################################################################
#########################################################################################################





import pygame

pygame.init()

# defines the width and height of the display
display_width = 400
display_height = 400

# defines block width and height
block_height = 50
block_width = 50

# defines colours
white = (255, 255, 255)
black = (0, 0, 0)
teal = (0, 128, 128)

game_display = pygame.display.set_mode((display_width, display_height))
pygame.display.update()
clock = pygame.time.Clock()


class piece:
    x = 0  # x coordinate
    y = 0  # y coordinate
    rank = ""  # rank of the piece
    life = True  # is the piece dead or alive
    family = ""  # colour of the piece (black or white)
    pic = ""  # photo of the piece

    def __init__(self, x_position, y_position, p_rank, p_family):
        self.x = x_position
        self.y = y_position
        self.rank = p_rank
        self.family = p_family


selected_piece = piece
pie = [piece(0, 0, "p", "black"), piece(1, 0, "p", "black"), piece(2, 0, "p", "black"), piece(3, 0, "p", "black"),
       piece(4, 0, "p", "black"), piece(0, 1, "p", "black"), piece(1, 1, "p", "black"), piece(2, 0, "p", "black"),
       piece(3, 5, "p", "black"), piece(4, 0, "p", "black")]

print(pie[0].x, pie[0].y)


def initialize_piece():
    i = 0
    while i < 10:
        if pie[i].rank == "p":
            pygame.draw.rect(game_display, teal, ((2 * pie[i].x + 1) * 25, ((2 * pie[i].y + 1) * 25), 12, 12))
        i += 1


def clear():
    i = 0
    while i < 10:
        if pie[i].rank == "p":
            if (pie[i].x+pie[i].y)%2 == 0:
                pygame.draw.rect(game_display, white, ((2 * pie[i].x + 1) * 25, ((2 * pie[i].y + 1) * 25), 12, 12))
            else:
                pygame.draw.rect(game_display, black, ((2 * pie[i].x + 1) * 25, ((2 * pie[i].y + 1) * 25), 12, 12))

        i += 1


def move():
    pie[1].x += 0


def board_draw():
    x = 0
    y = 0

    for i in range(8):
        if i % 2 == 0:
            j = 0
        else:
            j = 1
        while j < 8:
            pygame.draw.rect(game_display, white, (i * 50, j * 50, block_width, block_height))
            j += 2
    pygame.display.update()


def select_block(x_cursor, y_cursor):
    for i in range(10):
        if pie[i].x == x_cursor and pie[i].y == y_cursor:
            print("selected ", x_cursor, " ", y_cursor)
            return pie[i]


def game():
    selec = False
    while True:

        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONUP:
                pos = pygame.mouse.get_pos()
                a = pos[0] // 50
                b = pos[1] // 50
                if not selec:
                    selected_piece = select_block(a, b)
                    selec = True
                    if selected_piece is not None:
                        print(selected_piece.x, " ", selected_piece.y)
                else:
                    print("hello")
                    if selected_piece is not None:
                        for i in range(10):
                            if pie[i].x == selected_piece.x and pie[i].y == selected_piece.y:
                                clear()
                                pie[i].x = a
                                pie[i].y = b

                    selec = False
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        board_draw()

        initialize_piece()
        pygame.display.update()

        clock.tick(30)


game()
