#########################################################################################################
############  Vidhyanshu __ Jain ########################################################################
#########################################################################################################





import pygame

pygame.init()

# defines the width and height of the display
display_width = 400
display_height = 400

# defines block width and height
block_height = 50
block_width = 50

# defines colours
white = (255, 255, 255)
black = (0, 0, 0)
teal = (0, 128, 128)
blue_black = (50, 50, 50)

game_display = pygame.display.set_mode((display_width, display_height))
pygame.display.update()
clock = pygame.time.Clock()

selected_family = "black"





class piece:
    x = 0  # x coordinate
    y = 0  # y coordinate
    rank = ""  # rank of the piece
    life = True  # is the piece dead or alive
    family = ""  # colour of the piece (black or white)
    pic = ""  # photo of the piece

    def __init__(self, x_position, y_position, p_rank, p_family):
        self.x = x_position
        self.y = y_position
        self.rank = p_rank
        self.family = p_family


selected_piece = piece
end_piece = piece
pie = [piece(0, 6, "p", "black"), piece(1, 6, "p", "black"), piece(2, 6, "p", "black"), piece(3, 6, "p", "black"),
       piece(4, 6, "p", "black"), piece(5, 6, "p", "black"), piece(6, 6, "p", "black"), piece(7, 6, "p", "black"),
       piece(0, 1, "p", "white"), piece(1, 1, "p", "white"), piece(2, 1, "p", "white"), piece(3, 1, "p", "white"),
       piece(4, 1, "p", "white"), piece(5, 1, "p", "white"), piece(6, 1, "p", "white"), piece(7, 1, "p", "white")]

print(pie[0].x, pie[0].y)


def initialize_piece():
    i = 0
    while i < len(pie):
        if pie[i].rank == "p" and pie[i].life:
            # pygame.draw.rect(game_display, teal, ((2 * pie[i].x + 1) * 25, ((2 * pie[i].y + 1) * 25), 12, 12))
            try:
                if pie[i].family == "white":
                    img = pygame.image.load("pawn_white.png")
                else:
                    img = pygame.image.load("pawn_black.png")
                game_display.blit(img, ((2 * pie[i].x) * 25, ((2 * pie[i].y) * 25)))
            except Exception as e:
                print()
        i += 1


def clear():
    i = 0
    while i < len(pie):
        if (pie[i].x + pie[i].y) % 2 == 0:
            pygame.draw.rect(game_display, white, ((2 * pie[i].x + 1) * 25, ((2 * pie[i].y + 1) * 25), 12, 12))
        else:
            pygame.draw.rect(game_display, blue_black, ((2 * pie[i].x + 1) * 25, ((2 * pie[i].y + 1) * 25), 12, 12))

        i += 1


def move(orignal_x, orignal_y, final_x, final_y):
    val = False
    print(final_x, "+", final_y)
    global selected_family
    fam = selected_family
    for i in range(len(pie)):
        if pie[i].x == orignal_x and pie[i].y == orignal_y and pie[i].life and pie[i].family == fam:
            for k in range(len(pie)):
                if pie[k].x == final_x and pie[k].y == final_y and pie[k].life:
                    # If the pieces are not of same family then
                  ############## For pawns  ###################
                    if pie[i].rank == 'p':
                        if pie[k].family != pie[i].family and orignal_x != final_x:
                            if orignal_x + 1 == final_x or orignal_x - 1 == final_x:
                                if pie[i].family == "black":
                                    direction = -1
                                else:
                                    direction = 1
                                if orignal_y + direction == final_y:
                                    pie[k].life = False
                                    pie[i].x = final_x
                                    pie[i].y = final_y
                                    if pie[i].family == "white":
                                        selected_family = "black"
                                    else:
                                        selected_family = "white"
                                    clear()
                            print(pie[k].x, pie[k].y, " <--")
                        else:
                            val = True

    if val is False:

        for i in range(len(pie)):
            if pie[i].x == orignal_x and pie[i].y == orignal_y and pie[i].family == selected_family:
                clear()
                ####### These are the movement restrictions of a pawn:  ###############
                if pie[i].rank == "p":
                    if pie[i].family == "black":
                        direction = -1
                    else:
                        direction = 1
                    if orignal_y == 6 or orignal_y == 1:
                        if final_y == orignal_y + (2 * direction) and final_x == orignal_x:
                            rigt_upfront = False
                            for k in range(len(pie)):
                                if pie[k].y == orignal_y+direction and pie[k].x == orignal_x:
                                    rigt_upfront = True
                            if not rigt_upfront:
                                pie[i].x = final_x
                                pie[i].y = final_y
                                if pie[i].family == "white":
                                    selected_family = "black"
                                else:
                                    selected_family = "white"
                    if final_y == orignal_y + direction and final_x == orignal_x:
                        pie[i].x = final_x
                        pie[i].y = final_y
                        if pie[i].family == "white":
                            selected_family = "black"
                        else:
                            selected_family = "white"
                ########## Queen ###############################



def board_draw():
    x = 0
    y = 0
    game_display.fill(blue_black)
    selected_family = "black"
    for i in range(8):
        if i % 2 == 0:
            j = 0
        else:
            j = 1
        while j < 8:
            pygame.draw.rect(game_display, white, (i * 50, j * 50, block_width, block_height))
            j += 2


def select_block(x_cursor, y_cursor):
    selected_piece = None
    for i in range(len(pie)):
        if pie[i].x == x_cursor and pie[i].y == y_cursor:
            print("selected ", x_cursor, " ", y_cursor)
            return pie[i]


def game():
    selec = False
    global selected_family
    while True:

        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONUP:
                pos = pygame.mouse.get_pos()
                a = pos[0] // 50
                b = pos[1] // 50
                if not selec:
                    selected_piece = select_block(a, b)
                    selec = True
                    if selected_piece is not None:
                        print(selected_piece.x, " ", selected_piece.y)
                    else:
                        selec = False
                else:
                    print("hello")
                    if selected_piece is not None:
                        move(selected_piece.x, selected_piece.y, a, b)
                    selec = False
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        board_draw()

        initialize_piece()
        pygame.display.update()

        clock.tick(20)


game()
